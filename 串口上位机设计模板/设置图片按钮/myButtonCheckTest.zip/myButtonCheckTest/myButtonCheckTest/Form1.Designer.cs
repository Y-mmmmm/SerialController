﻿namespace myButtonCheckTest
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.myButtonCheck11 = new myButtonCheckTest.myButtonCheck();
            this.myButtonCheck12 = new myButtonCheckTest.myButtonCheck();
            this.myButtonCheck9 = new myButtonCheckTest.myButtonCheck();
            this.myButtonCheck10 = new myButtonCheckTest.myButtonCheck();
            this.myButtonCheck8 = new myButtonCheckTest.myButtonCheck();
            this.myButtonCheck7 = new myButtonCheckTest.myButtonCheck();
            this.myButtonCheck6 = new myButtonCheckTest.myButtonCheck();
            this.myButtonCheck5 = new myButtonCheckTest.myButtonCheck();
            this.myButtonCheck4 = new myButtonCheckTest.myButtonCheck();
            this.myButtonCheck3 = new myButtonCheckTest.myButtonCheck();
            this.myButtonCheck2 = new myButtonCheckTest.myButtonCheck();
            this.myButtonCheck1 = new myButtonCheckTest.myButtonCheck();
            this.SuspendLayout();
            // 
            // myButtonCheck11
            // 
            this.myButtonCheck11.BackColor = System.Drawing.Color.Transparent;
            this.myButtonCheck11.Checked = false;
            this.myButtonCheck11.CheckStyleX = myButtonCheckTest.CheckStyle.style6;
            this.myButtonCheck11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.myButtonCheck11.Location = new System.Drawing.Point(254, 100);
            this.myButtonCheck11.Name = "myButtonCheck11";
            this.myButtonCheck11.Size = new System.Drawing.Size(87, 27);
            this.myButtonCheck11.TabIndex = 11;
            // 
            // myButtonCheck12
            // 
            this.myButtonCheck12.BackColor = System.Drawing.Color.Transparent;
            this.myButtonCheck12.Checked = true;
            this.myButtonCheck12.CheckStyleX = myButtonCheckTest.CheckStyle.style6;
            this.myButtonCheck12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.myButtonCheck12.Location = new System.Drawing.Point(370, 100);
            this.myButtonCheck12.Name = "myButtonCheck12";
            this.myButtonCheck12.Size = new System.Drawing.Size(87, 27);
            this.myButtonCheck12.TabIndex = 10;
            // 
            // myButtonCheck9
            // 
            this.myButtonCheck9.BackColor = System.Drawing.Color.Transparent;
            this.myButtonCheck9.Checked = true;
            this.myButtonCheck9.CheckStyleX = myButtonCheckTest.CheckStyle.style5;
            this.myButtonCheck9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.myButtonCheck9.Location = new System.Drawing.Point(254, 59);
            this.myButtonCheck9.Name = "myButtonCheck9";
            this.myButtonCheck9.Size = new System.Drawing.Size(87, 27);
            this.myButtonCheck9.TabIndex = 9;
            // 
            // myButtonCheck10
            // 
            this.myButtonCheck10.BackColor = System.Drawing.Color.Transparent;
            this.myButtonCheck10.Checked = false;
            this.myButtonCheck10.CheckStyleX = myButtonCheckTest.CheckStyle.style5;
            this.myButtonCheck10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.myButtonCheck10.Location = new System.Drawing.Point(370, 59);
            this.myButtonCheck10.Name = "myButtonCheck10";
            this.myButtonCheck10.Size = new System.Drawing.Size(87, 27);
            this.myButtonCheck10.TabIndex = 8;
            // 
            // myButtonCheck8
            // 
            this.myButtonCheck8.BackColor = System.Drawing.Color.Transparent;
            this.myButtonCheck8.Checked = false;
            this.myButtonCheck8.CheckStyleX = myButtonCheckTest.CheckStyle.style4;
            this.myButtonCheck8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.myButtonCheck8.Location = new System.Drawing.Point(254, 12);
            this.myButtonCheck8.Name = "myButtonCheck8";
            this.myButtonCheck8.Size = new System.Drawing.Size(87, 27);
            this.myButtonCheck8.TabIndex = 7;
            // 
            // myButtonCheck7
            // 
            this.myButtonCheck7.BackColor = System.Drawing.Color.Transparent;
            this.myButtonCheck7.Checked = true;
            this.myButtonCheck7.CheckStyleX = myButtonCheckTest.CheckStyle.style4;
            this.myButtonCheck7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.myButtonCheck7.Location = new System.Drawing.Point(370, 12);
            this.myButtonCheck7.Name = "myButtonCheck7";
            this.myButtonCheck7.Size = new System.Drawing.Size(87, 27);
            this.myButtonCheck7.TabIndex = 6;
            // 
            // myButtonCheck6
            // 
            this.myButtonCheck6.BackColor = System.Drawing.Color.Transparent;
            this.myButtonCheck6.Checked = true;
            this.myButtonCheck6.CheckStyleX = myButtonCheckTest.CheckStyle.style3;
            this.myButtonCheck6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.myButtonCheck6.Location = new System.Drawing.Point(12, 100);
            this.myButtonCheck6.Name = "myButtonCheck6";
            this.myButtonCheck6.Size = new System.Drawing.Size(87, 27);
            this.myButtonCheck6.TabIndex = 5;
            // 
            // myButtonCheck5
            // 
            this.myButtonCheck5.BackColor = System.Drawing.Color.Transparent;
            this.myButtonCheck5.Checked = false;
            this.myButtonCheck5.CheckStyleX = myButtonCheckTest.CheckStyle.style3;
            this.myButtonCheck5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.myButtonCheck5.Location = new System.Drawing.Point(128, 100);
            this.myButtonCheck5.Name = "myButtonCheck5";
            this.myButtonCheck5.Size = new System.Drawing.Size(87, 27);
            this.myButtonCheck5.TabIndex = 4;
            // 
            // myButtonCheck4
            // 
            this.myButtonCheck4.BackColor = System.Drawing.Color.Transparent;
            this.myButtonCheck4.Checked = false;
            this.myButtonCheck4.CheckStyleX = myButtonCheckTest.CheckStyle.style2;
            this.myButtonCheck4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.myButtonCheck4.Location = new System.Drawing.Point(12, 57);
            this.myButtonCheck4.Name = "myButtonCheck4";
            this.myButtonCheck4.Size = new System.Drawing.Size(87, 27);
            this.myButtonCheck4.TabIndex = 3;
            // 
            // myButtonCheck3
            // 
            this.myButtonCheck3.BackColor = System.Drawing.Color.Transparent;
            this.myButtonCheck3.Checked = true;
            this.myButtonCheck3.CheckStyleX = myButtonCheckTest.CheckStyle.style2;
            this.myButtonCheck3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.myButtonCheck3.Location = new System.Drawing.Point(128, 57);
            this.myButtonCheck3.Name = "myButtonCheck3";
            this.myButtonCheck3.Size = new System.Drawing.Size(87, 27);
            this.myButtonCheck3.TabIndex = 2;
            // 
            // myButtonCheck2
            // 
            this.myButtonCheck2.BackColor = System.Drawing.Color.Transparent;
            this.myButtonCheck2.Checked = false;
            this.myButtonCheck2.CheckStyleX = myButtonCheckTest.CheckStyle.style1;
            this.myButtonCheck2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.myButtonCheck2.Location = new System.Drawing.Point(128, 12);
            this.myButtonCheck2.Name = "myButtonCheck2";
            this.myButtonCheck2.Size = new System.Drawing.Size(87, 27);
            this.myButtonCheck2.TabIndex = 1;
            // 
            // myButtonCheck1
            // 
            this.myButtonCheck1.BackColor = System.Drawing.Color.Transparent;
            this.myButtonCheck1.Checked = true;
            this.myButtonCheck1.CheckStyleX = myButtonCheckTest.CheckStyle.style1;
            this.myButtonCheck1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.myButtonCheck1.Location = new System.Drawing.Point(12, 12);
            this.myButtonCheck1.Name = "myButtonCheck1";
            this.myButtonCheck1.Size = new System.Drawing.Size(87, 27);
            this.myButtonCheck1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(470, 148);
            this.Controls.Add(this.myButtonCheck11);
            this.Controls.Add(this.myButtonCheck12);
            this.Controls.Add(this.myButtonCheck9);
            this.Controls.Add(this.myButtonCheck10);
            this.Controls.Add(this.myButtonCheck8);
            this.Controls.Add(this.myButtonCheck7);
            this.Controls.Add(this.myButtonCheck6);
            this.Controls.Add(this.myButtonCheck5);
            this.Controls.Add(this.myButtonCheck4);
            this.Controls.Add(this.myButtonCheck3);
            this.Controls.Add(this.myButtonCheck2);
            this.Controls.Add(this.myButtonCheck1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private myButtonCheck myButtonCheck1;
        private myButtonCheck myButtonCheck2;
        private myButtonCheck myButtonCheck3;
        private myButtonCheck myButtonCheck4;
        private myButtonCheck myButtonCheck5;
        private myButtonCheck myButtonCheck6;
        private myButtonCheck myButtonCheck7;
        private myButtonCheck myButtonCheck8;
        private myButtonCheck myButtonCheck9;
        private myButtonCheck myButtonCheck10;
        private myButtonCheck myButtonCheck11;
        private myButtonCheck myButtonCheck12;

    }
}

